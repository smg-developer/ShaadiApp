package com.challenge.shaadiapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.challenge.shaadiapp.R;
import com.challenge.shaadiapp.modal.User;

import java.util.ArrayList;

public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.UserViewHolder> {

    ArrayList<User> userDataSet;
    public UserListAdapter (ArrayList<User> arrListUsers){
        userDataSet = arrListUsers;
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        public TextView tvFirstName;
        public TextView tvDate;
        public View layout;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            layout = itemView;

            tvFirstName = itemView.findViewById(R.id.text_name);
            tvDate = itemView.findViewById(R.id.text_date);



        }
    }

    @Override
    public UserListAdapter.UserViewHolder onCreateViewHolder(ViewGroup parent,
                                                             int viewType) {
        // create a new view
        View userView = (View) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_cell, parent, false);

        UserViewHolder vh = new UserViewHolder(userView);
        return vh;
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {

        holder.tvFirstName.setText(userDataSet.get(position).name.toString());

    }

    @Override
    public int getItemCount() {
        return userDataSet.size();
    }
}

package com.challenge.shaadiapp;

import com.challenge.shaadiapp.modal.User;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Utility {

    public static ArrayList<User> parseUserList (JSONArray jArrayUsers){

        ArrayList<User> arrayUsers = new ArrayList<>();
        try{
            for (int position = 0; position < jArrayUsers.length(); position++){
                JSONObject jObjectUser = jArrayUsers.getJSONObject(position);
                final User userInfo = new Gson().fromJson(jObjectUser.toString(), User.class);

                arrayUsers.add(userInfo);
            }
        }
        catch (JSONException jsonException){
            jsonException.printStackTrace();
        }
        catch (Exception exception){
            exception.printStackTrace();
        }
        return arrayUsers;
    }
}

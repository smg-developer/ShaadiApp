package com.challenge.shaadiapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.challenge.shaadiapp.adapters.UserListAdapter;
import com.challenge.shaadiapp.modal.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static String TAG = "MainActivity";
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private String request_url = "https://randomuser.me/api/?results=10";

    private RecyclerView userRecyclerView;
    private RecyclerView.Adapter userRCAdapter;
    private RecyclerView.LayoutManager userLayoutManager;

    ArrayList<User> arrUsers = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Check Internet connection and load Data if network available.
        loadData();

        userRecyclerView = (RecyclerView) findViewById(R.id.rc_view_users);

        /*// use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);*/


    }

    private void loadData() {

        //RequestQueue initialized
        mRequestQueue = Volley.newRequestQueue(this);

        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.GET, request_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d(TAG, "Response: "+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e(TAG,"Error :" + error.toString());
            }
        });

        mRequestQueue.add(mStringRequest);
    }

    public void processDataResponse(String responseString){
        try {
            JSONObject jObjectResponse = new JSONObject(responseString);
            if(jObjectResponse.has("results")) {
                JSONArray jArrUsers = jObjectResponse.getJSONArray("results");

                arrUsers = Utility.parseUserList(jArrUsers);

                if(arrUsers.size() == 0){



                }
                else {
                    userRCAdapter = new UserListAdapter(arrUsers);
                    userRecyclerView.setAdapter(userRCAdapter);
                }
            }
            else {


            }

        }
        catch (Exception exception){
            exception.printStackTrace();
        }
    }
}